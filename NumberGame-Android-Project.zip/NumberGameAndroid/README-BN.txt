NUMBER GAME 1-100 — Android APK Project

এই প্রজেক্টে আপনার HTML গেমটি Android WebView অ্যাপ হিসেবে রাখা হয়েছে। গেমের HTML/JavaScript বদলানো হয়নি। LocalStorage চালু আছে, তাই Coin ও History ফোনে সেভ থাকবে।

APK বানানোর সহজ পদ্ধতি (GitHub Actions):
1. GitHub-এ একটি নতুন repository তৈরি করুন।
2. এই ZIP ফাইলটি Extract করে ভেতরের সব ফাইল repository-তে Upload করুন।
3. Commit করে main branch-এ Push করুন।
4. GitHub repository-তে Actions ট্যাব খুলুন।
5. “Build Android APK” workflow চালু/নির্বাচন করে Run workflow চাপুন।
6. Build শেষ হলে NumberGame-debug-apk নামে Artifact থেকে APK ডাউনলোড করুন।
7. Android ফোনে APK খুলে Install করুন। প্রয়োজনে “Install unknown apps” অনুমতি দিন।

নোট: এই পরিবেশে Android SDK/Gradle build tools নেই, তাই এখানে সরাসরি APK compile করা সম্ভব হয়নি। ZIP-টি Android Studio/Gradle build project এবং GitHub Actions workflow; এটি APK ফাইল নয়।
